$(document).ready(function () {
//set datatables
console.log('Done!');
   $('#dataTable').DataTable();

});

